SET
  SESSION sql_mode='';
SET
  NAMES 'utf8mb4';

/* Here you can insert data for installation with SQL requests */
